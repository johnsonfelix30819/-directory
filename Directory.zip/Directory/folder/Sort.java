package folder;

import java.util.Comparator;
import java.util.List;

public class Sort 
{
	public static void getSorted(List<FileStorage> fileStorage,int comparatorIndex,int ad)
	{
//ad -> ascending or descending, ad=0 for ascending and ad=non-zero for descending
// comparatorIndex 0 to 4;
		switch(comparatorIndex)
		{
		case 0:
			if(ad==0)
			{
				fileStorage.sort(Comparator.comparing(FileStorage::getFileName));
			}
			else
			{  
				fileStorage.sort(Comparator.comparing(FileStorage::getFileName,(s1,s2)->{return s2.compareTo(s1);}));
			}
			break;
		case 1:
			if(ad==0)
			{
				fileStorage.sort(Comparator.comparing(FileStorage::getDateModified));
			}
			else
			{
				Comparator<FileStorage> c=new Comparator<FileStorage>()
				{
					public int compare(FileStorage f1,FileStorage f2)
					{
						return Long.compare(f2.getDateModified(), f1.getDateModified());
						
					}
				};
					
				fileStorage.sort(c);
			}
			break;
		case 2:
			if(ad==0)
			{
				fileStorage.sort(Comparator.comparing(FileStorage::getType));
			}
			else
			{
				fileStorage.sort(Comparator.comparing(FileStorage::getType,(s1,s2)->{return s2.compareTo(s1);}));
			}
			break;
		case 3:
			if(ad==0)
			{
				fileStorage.sort(Comparator.comparing(FileStorage::getSize));
			}
			else
			{
				fileStorage.sort(Comparator.comparing(FileStorage::getSize,(s1,s2)->{return s2.compareTo(s1);}));
			}
			break;
		case 4:
			if(ad==0)
			{
				fileStorage.sort(Comparator.comparing(FileStorage::getPercentage));
			}
			else
			{
				fileStorage.sort(Comparator.comparing(FileStorage::getPercentage,(s1,s2)->{return s2.compareTo(s1);}));
			}
			break;
		}
			
	}
}
