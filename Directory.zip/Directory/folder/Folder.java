package folder;

import java.io.File;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Folder 
{
	public List<FileStorage> fileStorage=new ArrayList<FileStorage>(); //to store filename or foldername, dateModified,type, size, percentage
	public  long folderSize=0;
	public  ArrayList<Long> fileSize=new ArrayList<Long>();; // to store only folder or filesize
	public File currentFile=null;

	public Folder(String path)
	{
		getFiles(path);
	}

// Creates array from fileStorage and return to gui.java
	public  String[][] guiDisplay()
	{
		String printFiles[][]=new String[fileStorage.size()][5];
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
		DecimalFormat pctg = new DecimalFormat("#0.##");
		int i=0;
		for(FileStorage fs: fileStorage)
    	{
    		printFiles[i][0]=fs.getFileName();
    		printFiles[i][1]=sdf.format(fs.getDateModified())+"";
    		printFiles[i][2]=fs.getType()+"";
    		printFiles[i][3]=sizeFormate(fs.getSize())+"";
    		printFiles[i][4]=pctg.format(fs.getPercentage())+"%";
    		i++;
    	}
		return printFiles;
	}
	
// get all files in the path and stores in fileStorage object	
	public  void getFiles (String path) 
	{
		
		folderSize=0;
		File file=new File(path);
		if(file.exists())
		{
			if(file.isFile())
			{
				file=file.getParentFile();
			}
		}
		currentFile=file;
		folderSize=getSize(file);
		int count=0;
		for(File f: file.listFiles())
		{
			StoreDetails.storeDetails(f, count++, fileSize, fileStorage, folderSize);
		}

	}
	
// get size of the files and sub-files	
	public  long getSize(File file) 
	{
		long size=0;
		long subSize=size;
		try
		{
		    
		    if (file.isDirectory()) 
		    {
		    	
		    	for (File subFile : file.listFiles()) 
		        {
		    		size += getSize(subFile);
		    	}

		    	if(currentFile.equals(file.getParentFile()))
		    	{
		    		fileSize.add(size-subSize);
		    	}
		    	
		    	
		    } 
		    else 
		    {
		    	
		        size = file.length();
		        if(currentFile.equals(file.getParentFile()))
		    	{
		    		fileSize.add(size-subSize);
		    		
		    	}
		    }
		}
		catch(Exception e)
		{
			e.getStackTrace();
		}
	    return size;
	}
	
	
// formating bytes to Bytes, KB, MB, GB	
	public  String sizeFormate(double sizeBytes) 
	{
		String size="";
		String prefix[]= {"Bytes","KB","MB","GB"};
		DecimalFormat df = new DecimalFormat("#0.##");
		int getPrefix=0;
		while(sizeBytes>1024)
		{
			sizeBytes/=1024;
			getPrefix++;
		}
		size=df.format(sizeBytes)+" "+prefix[getPrefix];
		return size;
	}

}
