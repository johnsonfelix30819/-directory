package folder;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class StoreDetails 
{
	public static void storeDetails(File file,int count,ArrayList<Long> fileSize,List<FileStorage> fileStorage,long folderSize)
	{
		String name=file.getName();
		long dateModified=file.lastModified();
		String type="";
		if(file.isDirectory())
		{
			type="Folder";
		}
		else
		{
			type=name.substring(name.lastIndexOf(".")+1)+"_File";
		}
		try
		{
			long size=fileSize.get(count);
			double percentage=((double)size/folderSize)*100;
			FileStorage fs=new FileStorage(name,dateModified,type,size,percentage);
			fileStorage.add(fs);
		}
		catch(Exception e)
		{
			
		}
	}
}
