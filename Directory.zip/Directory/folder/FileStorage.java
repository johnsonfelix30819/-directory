package folder;

public class FileStorage 
{
	private String fileName;
	private long dateModified;
	private String type;
	private long size;
	private double percentage;
	public FileStorage(String fileName,long dateModified, String type, long size,double percentage)
	{
		this.setFileName(fileName);
		this.setDateModified(dateModified);
		this.setType(type);
		this.setSize(size);
		this.setPercentage(percentage);
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public long getDateModified() {
		return dateModified;
	}
	public void setDateModified(long dateModified) {
		this.dateModified = dateModified;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public long getSize() {
		return size;
	}
	public void setSize(long size) {
		this.size = size;
	}
	public double getPercentage() {
		return percentage;
	}
	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}
	
}
