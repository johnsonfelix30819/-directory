package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.*;
import javax.swing.table.*;
import folder.Folder;
import folder.Sort;

public class Gui extends JFrame implements ActionListener 
{
	int sortBy=0;
	int ad=0;  //Ascending or Descending
	String[] columnNames = {"Name", "DateModified", "Type", "Size", "Percentage"};
	File currentFile=null;
    DefaultTableModel model;
    JTable table=new JTable(model);
    JLabel defaultLabel=null;
    JPanel defaultPanel=null;
    JTextField directoryField;
    JButton goButton;
    JButton backButton;
    JScrollPane scrollPane=new JScrollPane(table);
    Font font=new Font("Serif", Font.PLAIN, 20);
    
    public Gui() 
    {
 	// directory panel    
		directoryField = new JTextField(50);
		directoryField.setFont(font);
		JLabel directoryLabel=new JLabel("Directory : ");
		directoryLabel.setFont(font);
		goButton=new JButton("GO");
		goButton.addActionListener(this);
		goButton.setFont(font);
		backButton=new JButton("Back");
		backButton.addActionListener(this);
		backButton.setFont(font);
		
		JPanel directoryPanel=new JPanel(new FlowLayout());
		directoryPanel.add(backButton);
		directoryPanel.add(directoryLabel);
		directoryPanel.add(directoryField);
		directoryPanel.add(goButton);
    	
        defaultLabel=new JLabel("Enter path and press Go");
        defaultLabel.setFont(font);
        defaultPanel=new JPanel(new FlowLayout());
        defaultPanel.add(defaultLabel);
        
        
        add(defaultPanel);
        add(directoryPanel,BorderLayout.NORTH);
   }
  //Go and back button action  
	@Override
	public void actionPerformed(ActionEvent event) 
	{
		if(event.getActionCommand().equalsIgnoreCase("GO"))
		{
			String path=directoryField.getText();
			setTitle(path);
			currentFile=new File(path);
			if(currentFile.getParentFile()==null)
			{
				backButton.setEnabled(false);
			}
			else
			{
				backButton.setEnabled(true);
			}
			
			Folder f=new Folder(path);
			display(f);
		}
		else
		{
			String path=currentFile.getParent();
			setTitle(path);
			currentFile=new File(path);
			if(currentFile.getParentFile()==null)
			{
				backButton.setEnabled(false);
			}
			Folder f=new Folder(path);
			directoryField.setText(path);
			display(f);	
		}

	}
	
	public void display(Folder f)
    {
    	
    	remove(defaultPanel);
    	remove(scrollPane);
    	Sort.getSorted(f.fileStorage, sortBy, ad);
		model = new DefaultTableModel(f.guiDisplay(), columnNames);
        table = new JTable(model) ;
        table.setEnabled(false);
        table.setShowVerticalLines(false);
        table.setFont(font);
        table.setRowHeight(50);
        table.getTableHeader().setFont(new Font("Serif", Font.BOLD, 20));
        scrollPane = new JScrollPane(table);
 // sorting rows  
        table.getTableHeader().addMouseListener(new MouseAdapter() 
        {
            @Override
            public void mouseClicked(MouseEvent e) 
            {
                int col = table.columnAtPoint(e.getPoint());
                sortBy=col;
                if(ad==0) ad=1; else ad=0;
                display(f);
            }
        });
  // Navigation to folders      
        table.addMouseListener(new MouseAdapter()
        {
        	public void mouseClicked(MouseEvent e)
        	{
        		int row=table.rowAtPoint(e.getPoint());
        		if(e.getClickCount()==2 && row!=-1 && e.getButton()==1)
        		{	
	        		String name=(String) table.getValueAt(row,0);
	        		String path=f.currentFile.toString()+"\\"+name;
	        		directoryField.setText(path);
	        		goButton.doClick();
	        		
        		}
        	}
        	
        });
 // show no. of files and Size at bottom      
        JPanel bottomPanel=new JPanel(new BorderLayout());
        JLabel itemsLabel=new JLabel("No. of Items : "+f.fileSize.size());
        JLabel sizeLabel=new JLabel("Size of the Folder : "+f.sizeFormate(f.folderSize));     
        itemsLabel.setFont(font);
        sizeLabel.setFont(font);
        
        bottomPanel.add(itemsLabel,BorderLayout.WEST);
        bottomPanel.add(sizeLabel,BorderLayout.EAST);
        
//adding content to frame     
        add(scrollPane);
        add(bottomPanel,BorderLayout.SOUTH);
        setVisible(true);
    }

}