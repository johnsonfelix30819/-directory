package gui;


import javax.swing.JFrame;

public class Main extends JFrame
{


	public static void main(String[] args) 
	{
       
		Gui frame = new Gui();
        frame.setSize(1500,900);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    
    }

}
